﻿/*
 * MemLCD.c
 *
 * Created: 2017-01-03 오후 10:03:50
 *  Author: Albireo
 */ 
 #include "MemLCD.h"

 #define SLAVE_SELECT_PIN  CONF_PIN_SPI_SSN

 //! [configure_spi]
 static void configure_spi_master(LCDSPIModule* module)
 {
	 //! [config]
	 struct spi_config config_spi_master;
	 //! [config]
	 //! [slave_config]
	 struct spi_slave_inst_config slave_dev_config;
	 //! [slave_config]
	 /* Configure and initialize software device instance of peripheral slave */
	 //! [slave_conf_defaults]
	 spi_slave_inst_get_config_defaults(&slave_dev_config);
	 //! [slave_conf_defaults]
	 //! [ss_pin]
	 slave_dev_config.ss_pin = SLAVE_SELECT_PIN;
	 //! [ss_pin]
	 //! [slave_init]
	 spi_attach_slave(&(module->LCD_slave), &slave_dev_config);
	 //! [slave_init]
	 /* Configure, initialize and enable SPI module */
	 //! [conf_defaults]
	 spi_get_config_defaults(&config_spi_master);
	 //! [conf_defaults]
	 //! [transfer_mode]
	 config_spi_master.transfer_mode = CONF_SPI_TRANSFER_MODE;
	 //! [transfer_mode]
	 //! [clock_divider]
	 config_spi_master.clock_divider = 154;
	 //! [clock_divider]
	 /* Configure pad 0 */
	 //! [sck]
	 config_spi_master.pin_number_pad[0] = CONF_SPI_PIN_SCK;
	 config_spi_master.pinmux_sel_pad[0] = CONF_SPI_MUX_SCK;
	 //! [sck]
	 /* Configure pad 1 */
	 //! [mosi]
	 config_spi_master.pin_number_pad[1] = CONF_SPI_PIN_MOSI;
	 config_spi_master.pinmux_sel_pad[1] = CONF_SPI_MUX_MOSI;
	 //! [mosi]
	 /* Configure pad 2 */
	 //! [ssn]
	 config_spi_master.pin_number_pad[2] = PINMUX_UNUSED;
	 config_spi_master.pinmux_sel_pad[2] = PINMUX_UNUSED;
	 //! [ssn]
	 /* Configure pad 3 */
	 //! [miso]
	 config_spi_master.pin_number_pad[3] = CONF_SPI_PIN_MISO;
	 config_spi_master.pinmux_sel_pad[3] = CONF_SPI_MUX_MISO;
	 //! [miso]
	 //! [init]
	 spi_init(&(module->LCD_spi_master_instance), CONF_SPI, &config_spi_master);
	 //! [init]

	 //! [enable]
	 spi_enable(&(module->LCD_spi_master_instance));
	 //! [enable]
 }

 void Setup(LCDSPIModule* module)
 {
	configure_spi_master(module);
 }

 void Transfer(uint8_t frameBuffer[FRAME_HEIGHT][FRAME_WIDTH], uint8_t startLine, uint8_t endLine, LCDSPIModule* module)
 {
		//! [select_slave]
		spi_select_slave(&(module->LCD_spi_master_instance), &(module->LCD_slave), false);
		//! [select_slave]

		//! [delay]
		for(uint16_t i = 0; i < 0xFF; i++) {
			/* Wait for the last data shift out */
		}
		//! [delay]

		//! [write]
		spi_write(&(module->LCD_spi_master_instance), 0x80);// M0=1 M1=0 M2=0 DMY=0

		for(uint8_t line_count = startLine; line_count <= endLine; line_count++)
		{
			spi_write(&(module->LCD_spi_master_instance), line_count); //Gate line address transfer
			spi_write_buffer_wait(&(module->LCD_spi_master_instance), frameBuffer[startLine], FRAME_WIDTH); //Data transfer
		}

		spi_write(&(module->LCD_spi_master_instance), 0);
		spi_write(&(module->LCD_spi_master_instance), 0); // Dummy
		//! [write]
		//! [delay]
		for(uint16_t i = 0; i < 0xFF; i++) {
			/* Wait for the last data shift out */
		}
		//! [delay]
		//! [deselect_slave]
		spi_select_slave(&(module->LCD_spi_master_instance), &(module->LCD_slave), true);
		//! [deselect_slave]
 }

 void Clear(uint8_t frameBuffer[FRAME_HEIGHT][FRAME_WIDTH])
 {
 	for(uint8_t i=0;i<FRAME_HEIGHT;i++)
 		for(uint8_t j=0;j<FRAME_WIDTH;j++)
 			frameBuffer[i][j] = 0;

 }